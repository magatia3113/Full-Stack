# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_browsable_object
from . import test_hr_payslip_worked_days
from . import test_hr_salary_rule
from . import test_payslip_flow
from . import test_hr_payroll_cancel
from . import test_hr_payslip_change_state
