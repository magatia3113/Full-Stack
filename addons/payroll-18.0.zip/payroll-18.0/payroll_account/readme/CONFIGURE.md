\# Go to *Payroll \> Configuration \> Salary Rules* \# Select rule that
you want in accounting \# Go to *Accounting Tab* and select Debit,
Credit Account
